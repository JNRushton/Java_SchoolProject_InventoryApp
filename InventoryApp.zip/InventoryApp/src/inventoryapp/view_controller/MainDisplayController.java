/*
 * Class: MainDisplayController
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */
package inventoryapp.view_controller;

import inventoryapp.InventoryApp;
import inventoryapp.model.Inventory;
import inventoryapp.model.Part;
import inventoryapp.model.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * @author Jennifer Rushton
 * 
 * FXML Controller class
 */
public class MainDisplayController {  
    
    @FXML
    private TableView<Part> partTable;
    @FXML
    private TableColumn<Part, Number> partIDColumn;
    @FXML
    private TableColumn<Part, String> partNameColumn;
    @FXML
    private TableColumn<Part, Number> partInStockColumn;
    @FXML
    private TableColumn<Part, Number> partPriceColumn;
    @FXML
    private TableView<Product> productTable;
    @FXML
    private TableColumn<Product, Number> productIDColumn;
    @FXML
    private TableColumn<Product, String> productNameColumn;
    @FXML
    private TableColumn<Product, Number> productInStockColumn;
    @FXML
    private TableColumn<Product, Number> productPriceColumn;
    @FXML
    private TextField searchPartText;
    @FXML
    private TextField searchProductText;
    
    // Reference to the main InventoryApp application display
    private InventoryApp mainDisplay;
    
    
    /**
     * Initializes the controller class. This method is automatically called
     * after the FXML file has been loaded.
     */
    @FXML
    private void initialize() {
        
        // Initialize the part table
        partIDColumn.setCellValueFactory(cellData -> cellData.getValue().partIDProperty());
        partNameColumn.setCellValueFactory(cellData -> cellData.getValue().partNameProperty());
        partInStockColumn.setCellValueFactory(cellData -> cellData.getValue().partInStockProperty());
        partPriceColumn.setCellValueFactory(cellData -> cellData.getValue().partPriceProperty());
        
        // Initialize the product table
        productIDColumn.setCellValueFactory(cellData -> cellData.getValue().productIDProperty());
        productNameColumn.setCellValueFactory(cellData -> cellData.getValue().productNameProperty());
        productInStockColumn.setCellValueFactory(cellData -> cellData.getValue().productInStockProperty());
        productPriceColumn.setCellValueFactory(cellData -> cellData.getValue().productPriceProperty());
        
        // Set tables
        partTable.setItems(Inventory.getParts());
        productTable.setItems(Inventory.getProducts());
        
    }
    
    /**
     * Called by the main InventoryApp application to give a reference 
     * back to itself.
     * 
     * @param {InventoryApp} mainDisplay - the main InventoryApp application
     */    
    public void setDisplay(InventoryApp mainDisplay) {
        
        // Set display as main display
        this.mainDisplay = mainDisplay;
        
        // Add observable list data to the tables
        partTable.setItems(Inventory.getParts());
        productTable.setItems(Inventory.getProducts());
        
    }
    
    /**
     * Called when the user clicks the Add part button. Opens a dialog window
     * to enter details for a new part.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleAddPart(ActionEvent event) throws Exception {
        boolean okClicked = mainDisplay.showAddPartsDisplay();
    }
    
    /**
     * Called when the user clicks the Add product button. Opens a dialog 
     * window to enter details for a new product.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleAddProduct(ActionEvent event) throws Exception {
        boolean okClicked = mainDisplay.showAddProductsDisplay();
    }
    
    /**
     * Called when the user clicks the Delete part button. Asks user to confirm 
     * deletion and then deletes the selected part.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleDeletePart(ActionEvent event) {
        
        // Set selected part
        Part selectedPart = partTable.getSelectionModel().getSelectedItem();
        
        // Selected part is not null - delete part
        if (selectedPart != null) {
            
            // Confirm Deletion
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Deletion");
            alert.setHeaderText("Deleting...");
            alert.setContentText("Would you like to delete part " 
                    + selectedPart.getName() + " now?");        
            alert.showAndWait()
                    .filter(response -> response == ButtonType.OK)
                    .ifPresent(response -> Inventory.getParts().remove(selectedPart));
            
            // Update part table
            partTable.setItems(Inventory.getParts());
            
        // No part selected - raise error
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Selection Required");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("Please select a Part from the table and try again.");
            alert.showAndWait();
        }
    }
    
    /**
     * Called when the user clicks the Delete product button. Asks user to 
     * confirm deletion and then deletes the selected product.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleDeleteProduct(ActionEvent event) {
        
        // Set selected product
        Product selectedProduct = productTable.getSelectionModel().getSelectedItem();
        
        // Selected product is not null - delete product
        if (selectedProduct != null) {
            
            // Confirm Deletion
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Deletion");
            alert.setHeaderText("Deleting...");
            alert.setContentText("Would you like to delete product " 
                    + selectedProduct.getName() + " now?");        
            alert.showAndWait()
                    .filter(response -> response == ButtonType.OK)
                    .ifPresent(response -> Inventory.getProducts().remove(selectedProduct));
            
            // Update product table
            productTable.setItems(Inventory.getProducts());
            
        // No product selected - raise error
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Selection Required");
            alert.setHeaderText("No Product Selected");
            alert.setContentText("Please select a Product from the table and try again.");
            alert.showAndWait();
        }
    }
    
    /**
     * Called when the user clicks the Exit button. Closes the program.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleExit(ActionEvent event) {
        
        // Confirms user wants to exit the program and closes the program
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Confirmation");
        alert.setHeaderText("Would you like to exit the program?");
        alert.setContentText("Selecting OK will close the program.");        
        alert.showAndWait().filter(response -> response == ButtonType.OK)
                .ifPresent(response -> System.exit(0));
    }   
    
    /**
     * Called when the user clicks the Modify part button. Opens a dialog 
     * window to edit details for the selected part.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleModifyPart(ActionEvent event) {
        
        // Set selected part
        Part selectedPart = partTable.getSelectionModel().getSelectedItem();
        
        /* Selected part is not null - open modify part window 
           and send selected part to new window */
        if (selectedPart != null) {
            boolean okClicked = mainDisplay.showModifyPartsDisplay(selectedPart);
            
        // No part selected - raise error
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(mainDisplay.getPrimaryStage());
            alert.setTitle("Selection Required");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("Please select a part in the table and try again.");
            alert.showAndWait();
        }
    }

    /**
     * Called when the user clicks the Modify product button. Opens a dialog 
     * window to edit details for the selected product.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML 
    private void handleModifyProduct(ActionEvent event) {
        
        // Set selected product
        Product selectedProduct = productTable.getSelectionModel().getSelectedItem();
        
        /* Selected product is not null - open modify product window 
           and send selected product to new window */
        if (selectedProduct != null) {
            boolean okClicked = mainDisplay.showModifyProductsDisplay(selectedProduct);
            
        // No product selected - raise error
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(mainDisplay.getPrimaryStage());
            alert.setTitle("Selection Required");
            alert.setHeaderText("No Product Selected");
            alert.setContentText("Please select a product in the table and try again.");
            alert.showAndWait();
        }
    }
    
    /** Called when the user clicks the Reset part button. Resets the part 
     * table back to all available parts.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleResetPartSearch(ActionEvent event) {
        partTable.setItems(Inventory.getParts());
        searchPartText.setText(null);
    }
    
    /** Called when the user clicks the Reset product button. Resets the product
     * table back to all available products.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleResetProductSearch(ActionEvent event) {
        productTable.setItems(Inventory.getProducts());
        searchProductText.setText(null);
    }
    
    /**
     * Called when the user clicks the Search part button. Searches part table
     * for a matching part ID or part name and returns all matching parts.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleSearchParts(ActionEvent event) {
        
        // Set search text
        String searchText = searchPartText.getText();
        
        // Search text not null - perform search
        if (searchText.isEmpty() == false) {
            
            // Set part table to results of part search
            partTable.setItems(Inventory.searchForPart(searchText));
            
        // Search text null - raise error
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Search Text Required");
            alert.setHeaderText("Search box cannot be blank");
            alert.setContentText("Please enter text in search field and try again.");
            alert.showAndWait();
        }
    }
    
    /**
     * Called when the user clicks the Search product button. Searches product 
     * table for a matching product ID or product name and returns all 
     * matching products.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleSearchProducts(ActionEvent event) {
        
        // Set search text
        String searchText = searchProductText.getText();
        
        // Search text not null - perform search
        if (searchText.isEmpty() == false) {
            
            // Set product table to results of product search
            productTable.setItems(Inventory.searchForProduct(searchText));
            
        // Search text null - raise error
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Search Text Required");
            alert.setHeaderText("Search box cannot be blank");
            alert.setContentText("Please enter text in search field and try again.");
            alert.showAndWait();
        }
    }
    
}