/*
 * Class: PartController
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 *
 * NOTE: InhousePartController and OutsourcedPartController have both been
 * combined into PartController. InhousePart.fxml and OutsourcedPart.fxml have
 * also both been combined into Part.fxml.
 */
package inventoryapp.view_controller;

import inventoryapp.InventoryApp;
import inventoryapp.model.InhousePart;
import inventoryapp.model.Inventory;
import inventoryapp.model.OutsourcedPart;
import inventoryapp.model.Part;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * @author Jennifer Rushton
 * 
 * FXML Controller class
 */
public class PartController {
    
    @FXML
    private Label category;
    @FXML
    private Label titleLabel;
    @FXML
    private RadioButton inhouseOption;
    @FXML
    private RadioButton outsourcedOption;
    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField invField;
    @FXML
    private TextField priceField;
    @FXML
    private TextField maxField;
    @FXML
    private TextField minField;
    @FXML
    private TextField categoryField;
    
    // Reference to the main application display
    private InventoryApp mainDisplay;
    private Stage dialogStage;
    
    // Local part that is being added or modified
    private Part part;
    
    // Sets whether local part is new for adding, or not new for modifying
    private boolean isNew;
    
    private boolean okClicked = false;
    
    
    /**
     * Initializes the controller class. This method is automatically called
     * after the FXML file has been loaded.
     */
    public void initialize() {

        // Sets local part to new for adding 
        isNew = true;
        
        // Sets radio buttons to default settings
        inhouseOption.setSelected(true);
        outsourcedOption.setSelected(false);
        
    }
    
    /** 
     * Sets the part's category based on whether Inhouse or Outsourced is
     * selected.
     * 
     * @param {String} category - string to set the part's category
     */
    public void setCategory(String category) {
        this.category.setText(category);
    }
    
    /**
     * Sets the stage of this dialog.
     * 
     * @param {Stage} dialogStage - sets the new stage for the popup dialog
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    /**
     * Called by the main application to give a reference back to itself.
     * 
     * @param {InventoryApp} mainDisplay - the main InventoryApp application
     */
    public void setDisplay(InventoryApp mainDisplay) {
        this.mainDisplay = mainDisplay;
    }
    
    /** 
     * Sets the local part to part selected from table. Only called when
     * part already exists and is being modified.
     * 
     * @param {Part} part - selected part is passed for modifications
     */
    public void setPart(Part part) {
        
        // Part is being modified, not new
        isNew = false;
        
        // Set local part to part parameter
        this.part = part;
        
        // Set text fields to local part's information
        idField.setText(Integer.toString(part.getPartID()));
        nameField.setText(part.getName());
        invField.setText(Integer.toString(part.getInStock()));
        priceField.setText(Double.toString(part.getPrice()));
        maxField.setText(Integer.toString(part.getMax()));
        minField.setText(Integer.toString(part.getMin()));
        categoryField.setText(part.getCategoryText());
        category.setText(part.getCategory());
        
        // If part is Inhouse, set radio buttons to Inhouse default
        if (part instanceof InhousePart) {
            inhouseOption.setSelected(true);
            outsourcedOption.setSelected(false);  
            
        // If part is Outsourced, set radio buttons to Outsourced default
        } else if (part instanceof OutsourcedPart) {
            inhouseOption.setSelected(false);
            outsourcedOption.setSelected(true);
        }
    }
    
    /** 
     * Sets the dialog window's title
     * 
     * @param {String} title - string to set the dialog window's title
     */
    public void setTitle(String title) {
        this.titleLabel.setText(title);
    }

    /**
     * Called when the user clicks the Cancel button. Closes the dialog window.
     */
    @FXML
    private void handleCancelPart() {
        
        // Confirms cancellation and closes part window
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Cancel Confirmation");
        alert.setHeaderText("Cancelling will close this window and all changes will be lost.");
        alert.setContentText("Would you still like to cancel the changes?");
        alert.showAndWait().filter(response -> response == ButtonType.OK)
                .ifPresent(response -> dialogStage.close());
    }
    
    /**
     * Called when the user clicks the Inhouse radio option. Selects Inhouse
     * option, deselects Outsourced option, and sets Category label to
     * "Machine ID" instead of "Company Name".
     */
    @FXML
    private void handleInhouseOption() {
        inhouseOption.setSelected(true);
        outsourcedOption.setSelected(false);
        category.setText("Machine ID");
    }
    
    /**
     * Called when the user clicks the Outsourced radio option. Selects
     * Outsourced option, deselects Inhouse option, and sets the Category
     * label to "Company Name" instead of "Machine ID".
     */
    @FXML
    private void handleOutsourcedOption() {
        outsourcedOption.setSelected(true);
        inhouseOption.setSelected(false);
        category.setText("Company Name");
    }
    
    /** 
     * Called when the user clicks the Save product button. Saves current 
     * local part and closes the dialog window.
     */
    @FXML
    private void handleSavePart() {
        

        int machineID = 0;
        String companyName = null;
        String category = null;
        
        // Create alert, if needed
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Save Failed");
        alert.setContentText("Please correct and try again.");
        
        // Check inventory (inStock) to see if it is empty 
        if (invField.getText().isEmpty() == true) {
            
            // Set default to 0 if empty
            invField.setText("0");
        }
        
        // Verify text fields are not blank
        if ((idField.getText().isEmpty() == true) || (nameField.getText().isEmpty() == true)
                || (priceField.getText().isEmpty() == true) || (invField.getText().isEmpty() == true)
                || (minField.getText().isEmpty() == true) || (maxField.getText().isEmpty() == true) 
                || (categoryField.getText().isEmpty() == true)) {
            
            // Show missing required information error if any fields are blank
            alert.setTitle("Missing Required Information");
            alert.setHeaderText("One or more required fields are blank.");
            alert.showAndWait();
            
        // Text fields are not missing required information
        } else {
            
            // Create variables for all text fields
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            double price = Double.parseDouble(priceField.getText());
            int inventory = Integer.parseInt(invField.getText());
            int min = Integer.parseInt(minField.getText());
            int max = Integer.parseInt(maxField.getText());
        
            // Verifies that the min is less than max and max is greater than min
            if (min > max) {
                alert.setHeaderText("Minimum value must be less than the maximum value.");
                alert.showAndWait();

            // Verifies that the inventory (inStock) value is between the min and max
            } else if ((max < inventory) || (inventory < min)) {
                alert.setHeaderText("Inventory value must be between the minimum and maximum values.");
                alert.showAndWait();

            // Verifies that part ID doesn't already exist  
            } else if ((Inventory.isPartFound(id) == true) && (part.getPartID() != id)) {
                alert.setHeaderText("Part ID already exists.");
                alert.showAndWait();
                
            // Part passed checks, okay to save part 
            } else {
                
                // Check if part is being saved as inhouse
                if ((inhouseOption.isSelected() == true) && (outsourcedOption.isSelected() == false)) {

                    // Part is inhouse - set machine ID and category
                    machineID = Integer.parseInt(categoryField.getText());
                    category = "Machine ID";

                // Check if part is being saved as outsourced    
                } else if ((outsourcedOption.isSelected() == true) && (inhouseOption.isSelected() == false)){

                    // Part is outsourced - set company name and category
                    companyName = categoryField.getText();
                    category = "Company Name";

                }

                // Part already exists
                if (isNew == false) {

                    // Check if part is currently inhouse and staying inhouse, then save
                    // OR Check if part is currently outsourced and staying outsourced, then save
                    if (((category == "Machine ID") && (part.getCategory() == "Machine ID")) ||
                            ((category == "Company Name") && (part.getCategory() == "Company Name"))) {

                        // Modify local part
                        part.setPartID(id);
                        part.setName(name);
                        part.setPrice(price);
                        part.setInStock(inventory);
                        part.setMin(min);
                        part.setMax(max);

                        // Inhouse part
                        if (category == "Machine ID") {
                            part.setMachineID(machineID);   

                        // Outsourced part
                        } else if (category == "Company Name") {
                            part.setCompanyName(companyName);       
                        }

                    // Check if part is currently inhouse and changing to outsourced
                    // OR Check if part is currently outsourced and changing to inhouse
                    } else if (((category == "Machine ID") && (part.getCategory() != "Machine ID")) ||
                            ((category == "Company Name") && (part.getCategory() != "Company Name"))) {

                        // Local part is changing categories, delete and treat as new part
                        Inventory.getParts().remove(part);
                        isNew = true;
                    }
                }

                // Local part is new
                if (isNew == true) {

                    // Check if part is inhouse - if true, create inhouse part
                    if (category == "Machine ID") {
                        part = new InhousePart(id, name, price, inventory, min, max, machineID);

                    // Check if part is outsourced - if true, create outsourced part
                    } else if (category == "Company Name") {
                        part = new OutsourcedPart(id, name, price, inventory, min, max, companyName);
                    }

                    // Add selected local part to all parts
                    Inventory.getParts().add(part);
                }

                // Set OK clicked to true and close popup dialog
                okClicked = true;
                dialogStage.close();

            }
        }
    }
    
    /** 
     * Returns true if the user clicked OK, false otherwise.
     * 
     * @return {boolean} Returns true if the user clicked OK, otherwise 
     * returns false
     */
    public boolean isOkClicked() {
        return okClicked;
    }

}
