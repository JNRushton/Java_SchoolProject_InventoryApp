/*
 * Class: ProductScreenController
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */

//there is a way to get rid of isNew - do i want to?
package inventoryapp.view_controller;

import inventoryapp.InventoryApp;
import inventoryapp.model.Inventory;
import inventoryapp.model.Part;
import inventoryapp.model.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * @author Jennifer Rushton
 * 
 * FXML Controller class
 */
public class ProductScreenController {
    
    @FXML
    private TableView<Part> allPartsTable;
    @FXML
    private TableColumn<Part, Number> allPartsIDColumn;
    @FXML
    private TableColumn<Part, String> allPartsNameColumn;
    @FXML
    private TableColumn<Part, Number> allPartsInStockColumn;
    @FXML
    private TableColumn<Part, Number> allPartsPriceColumn;
    @FXML
    private TableView<Part> associatedPartsTable;
    @FXML
    private TableColumn<Part, Number> associatedPartsIDColumn;
    @FXML
    private TableColumn<Part, String> associatedPartsNameColumn;
    @FXML
    private TableColumn<Part, Number> associatedPartsInStockColumn;
    @FXML
    private TableColumn<Part, Number> associatedPartsPriceColumn;
    @FXML
    private Label titleLabel;
    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField invField;
    @FXML
    private TextField priceField;
    @FXML
    private TextField maxField;
    @FXML
    private TextField minField;
    @FXML
    private TextField searchField;
    
    // Reference to the main InventoryApp application display
    private InventoryApp mainDisplay;
    private Stage dialogStage;
    
    // Local product that is being added or modified
    private Product product;
    
    // Sets whether local product is new for adding, or not new for modifying
    private boolean isNew = true;
    
    private boolean okClicked = false;
    
    
    /**
     * Initializes the controller class. This method is automatically called
     * after the FXML file has been loaded.
     */
    public void initialize() {
        
        // Initializes the all parts table
        allPartsIDColumn.setCellValueFactory(cellData -> cellData.getValue().partIDProperty());
        allPartsNameColumn.setCellValueFactory(cellData -> cellData.getValue().partNameProperty());
        allPartsInStockColumn.setCellValueFactory(cellData -> cellData.getValue().partInStockProperty());
        allPartsPriceColumn.setCellValueFactory(cellData -> cellData.getValue().partPriceProperty());
        
        // Initializes the associated parts table
        associatedPartsIDColumn.setCellValueFactory(cellData -> cellData.getValue().partIDProperty());
        associatedPartsNameColumn.setCellValueFactory(cellData -> cellData.getValue().partNameProperty());
        associatedPartsInStockColumn.setCellValueFactory(cellData -> cellData.getValue().partInStockProperty());
        associatedPartsPriceColumn.setCellValueFactory(cellData -> cellData.getValue().partPriceProperty());
        
        // Set table
        allPartsTable.setItems(Inventory.getParts());

    }
    
    /**
     * Sets the stage of this dialog.
     * 
     * @param {Stage} dialogStage - sets the new stage for the popup dialog
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    /**
     * Called by the main application to give a reference back to itself.
     * 
     * @param {InventoryApp} mainDisplay - the main InventoryApp application
     */
    public void setDisplay(InventoryApp mainDisplay) {
        this.mainDisplay = mainDisplay;
    }

    /** 
     * Sets the local product to product selected from table. Only called when
     * product already exists and is being modified.
     * 
     * @param {Product} product - selected product is passed for modifications
     */
    public void setProduct(Product product) {
        
        // Product is being modified, not new
        isNew = false;
        
        // Set local product to product parameter
        this.product = product;
        
        // Set associated parts table to local product's parts
        associatedPartsTable.setItems(product.getAssociatedParts());
        
        // Set text fields to local product's information
        idField.setText(Integer.toString(product.getProductID()));
        nameField.setText(product.getName());
        invField.setText(Integer.toString(product.getInStock()));
        priceField.setText(Double.toString(product.getPrice()));
        maxField.setText(Integer.toString(product.getMax()));
        minField.setText(Integer.toString(product.getMin()));
        
    }
    
    /** 
     * Sets the dialog window's title
     * 
     * @param {String} title - string to set the dialog window's title
     */
    public void setTitle(String title) {
        this.titleLabel.setText(title);
    }
    
    /** 
     * Called when the user clicks the Add product part button. Adds new part
     * to local product.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleAddProductPart(ActionEvent event) {
        
        // Check inventory (inStock) to see if it is empty
        if (invField.getText().isEmpty() == true) {
            
            // Set default to 0 if empty
            invField.setText("0");
        }

        // Verifies text fields are not blank
        if ((idField.getText().isEmpty() == true) || (nameField.getText().isEmpty() == true)
                || (priceField.getText().isEmpty() == true) || (invField.getText().isEmpty() == true)
                || (minField.getText().isEmpty() == true) || (maxField.getText().isEmpty() == true)) {
            
            // Throw error if any fields are blank
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Missing Required Information");
            alert.setHeaderText("One or more required fields are blank.");
            alert.setContentText("Please enter required information and try again.");
            alert.showAndWait();
        
        // Text fields are not missing required information    
        } else {
            
            // Create variables for all text fields
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            double price = Double.parseDouble(priceField.getText());
            int inventory = Integer.parseInt(invField.getText());
            int min = Integer.parseInt(minField.getText());
            int max = Integer.parseInt(maxField.getText());
        
            // Set selected part
            Part selectedPart = allPartsTable.getSelectionModel().getSelectedItem();

            if (selectedPart != null) {

                // Local product is new
                if (isNew == true) {

                    // Create product
                    product = new Product(id, name, price, inventory, min, max);

                    // Set back to false for future products
                    isNew = false;

                }

                if (isProductVerified(id, name, price, inventory, min, max) == true) {

                    // Add selected part to local product
                    this.product.addAssociatedPart(selectedPart);        
                }

                // Update associated parts table
                associatedPartsTable.setItems(product.getAssociatedParts());

            // No part selected - raise error    
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Selection Required");
                alert.setHeaderText("No Part Selected");
                alert.setContentText("Please select a Part from the table and try again.");
                alert.showAndWait();
            }
        }
    }
    
    /** 
     * Called when the user clicks the cancel button. Closes the dialog window.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleCancelProduct(ActionEvent event) {
        
        // Confirms cancellation and closes product window
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Cancel Confirmation");
        alert.setHeaderText("Cancelling will close this window and all changes will be lost.");
        alert.setContentText("Would you still like to cancel the changes?");
        alert.showAndWait().filter(response -> response == ButtonType.OK)
                .ifPresent(response -> dialogStage.close());
    }
    
    /** 
     * Called when the user clicks the Delete product part button. Asks user to 
     * confirm deletion and then deletes the selected part.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleDeleteProductPart(ActionEvent event) {
        
        // Set selected part
        Part selectedPart = associatedPartsTable.getSelectionModel().getSelectedItem();
        
        // Selected part is not null - delete part
        if (selectedPart != null) {
            
            // This is the last part associated with selected product - unable to delete
            if (this.product.getAssociatedParts().size() <= 1) {
                Alert warning = new Alert(Alert.AlertType.WARNING);
                warning.setTitle("Deletion Failed");
                warning.setHeaderText(selectedPart.getName() + 
                        " is the last part associated with product " 
                        + this.product.getName());
                warning.setContentText("Unable to delete product " + this.product.getName());
                warning.showAndWait();
                
            // Product still has other parts left
            } else {
                
                // Confirm Deletion
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirm Deletion");
                alert.setHeaderText("Deleting...");
                alert.setContentText("Would you like to delete part " 
                        + selectedPart.getName() + " from product " + this.product.getName() + "?");  
                alert.showAndWait()
                    .filter(response -> response == ButtonType.OK)
                    .ifPresent(response -> this.product.getAssociatedParts().remove(selectedPart));
            }
            
            // Update associated parts table
            associatedPartsTable.setItems(product.getAssociatedParts());
        
        // No part selected - raise error
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Selection Required");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("Please select a Part from the table and try again.");
            alert.showAndWait();
        }
    }
    
    /** 
     * Called when the user clicks the Save product button. Saves current 
     * local product and closes the dialog window.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleSaveProduct(ActionEvent event) {
        
        // Create variables for all text fields
        int id = Integer.parseInt(idField.getText());
        String name = nameField.getText();
        double price = Double.parseDouble(priceField.getText());
        int inventory = Integer.parseInt(invField.getText());
        int min = Integer.parseInt(minField.getText());
        int max = Integer.parseInt(maxField.getText());
        
        // No parts associated with selected product - unable to save
        if (associatedPartsTable.getItems().size() <= 0) {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Save Failed");
            warning.setHeaderText("No parts associated with current product");
            warning.setContentText("Unable to save product. Please add parts and try again");
            warning.showAndWait();
            
        // Verify product is valid    
        } else if (isProductVerified(id, name, price, inventory, min, max)) {

            // Local product is new
            if (isNew == true) {

                    // Create new product
                    product = new Product(id, name, price, inventory, min, max);

                    // Add all associated parts to new product
                    for (Part part : associatedPartsTable.getItems()) {
                        product.addAssociatedPart(part);
                    }
                   
                    // Add selected local product to all products
                    Inventory.getProducts().add(product);
                    
            // Product already exists
            } else if (isNew == false) {

                // Verify product is valid
                if (isProductVerified(id, name, price, inventory, min, max)) {
                    
                    // Modify local product
                    product.setProductID(id);
                    product.setName(name);
                    product.setPrice(price);
                    product.setInStock(inventory);
                    product.setMin(min);
                    product.setMax(max);
                }
            }

            // Set OK clicked to true and close popup dialog
            okClicked = true;
            dialogStage.close();
        } 
        
    }
    
    /** Called when the user clicks the Reset product part button. Resets
     * part table to show all available parts.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleResetProductPart(ActionEvent event) {
        allPartsTable.setItems(Inventory.getParts());
    }

    /** 
     * Called when the user clicks the Search product part button. Searches 
     * part table for a matching part ID or part name and returns all 
     * matching parts.
     * 
     * @param {ActionEvent} event - on button click
     */
    @FXML
    private void handleSearchProductPart(ActionEvent event) {
        
        // Set search text
        String searchText = searchField.getText();
        
        // Search all parts table for matching PartID or similar Part Name
        allPartsTable.setItems(Inventory.searchForPart(searchText));
        
    }
    
    /** 
     * Returns true if the user clicked OK, false otherwise.
     * 
     * @return {boolean} Returns true if the user clicked OK, otherwise 
     * returns false
     */
    public boolean isOkClicked() {
        return okClicked;
    }
    
    private boolean isProductVerified(int id, String name, double price, int inventory, int min, int max) {

        boolean isVerified = true;
    
        Alert warning = new Alert(Alert.AlertType.WARNING);
        warning.setTitle("Product Creation Failed");
        warning.setContentText("Unable to save product. Please fix issue and try again");
        
        // Verify min is less than max and max is greater than min
        if (min > max) {
            warning.setHeaderText("Product minimum is greater than product maximum.");
            isVerified = false;
            
        // Verify inventory (inStock) is between min and max    
        } else if ((max < inventory) || (inventory < min)) {
            warning.setHeaderText("Product inventory is not between the minimum and maximum.");
            isVerified = false;
            
        // Verify total cost of product parts is less than product price    
        } else if (price < product.getTotalPartsPrice()) {
            warning.setHeaderText("Total price of product parts is greater than product price.");
            isVerified = false;
            
        // Verify product has name, price, inventory level, and id
        } else if ((name == "") || ((price == 0) || (String.valueOf(price) == "")) 
                || (String.valueOf(inventory) == "") || (String.valueOf(id) == "")) {
            warning.setHeaderText("Product missing name, price, inventory level, or id.");
            isVerified = false;
            
        // Verify product ID doesn't already exist
        } else if ((Inventory.isProductFound(id) == true) && (product.getProductID() != id)) {
            warning.setHeaderText("Product ID already exists.");
            isVerified = false;
        }
        
        // If there is an error, show warning
        if (isVerified == false) {
            warning.showAndWait();
        }    
        return isVerified;
    }
    
}
