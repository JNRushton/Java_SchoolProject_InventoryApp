/*
 * Class: OutsourcedPart
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */
package inventoryapp.model;

/**
 * @author Jennifer Rushton
 * 
 * Model class for an OutsourcedPart
 */
public class OutsourcedPart extends Part {
    
    private String companyName;
    
    
    /**
     * The constructor - creates an Outsourced part.
     * 
     * @param {int} partID
     * @param {String} name
     * @param {double} price
     * @param {int} inStock
     * @param {int} min
     * @param {int} max
     * @param {String} companyName
     */
    public OutsourcedPart(int partID, String name, double price, int inStock, int min, int max, String companyName) {
                          super(partID, name, price, inStock, min, max, "Company Name");
        setCompanyName(companyName);
    }
    
    /**
     * The constructor - creates an Outsourced part - without companyName.
     * 
     * @param {int} partID
     * @param {String} name
     * @param {double} price
     * @param {int} inStock
     * @param {int} min
     * @param {int} max
     */
/*    public OutsourcedPart(int partID, String name, double price, int inStock, int min, int max) {
        super(partID, name, price, inStock, min, max, "Company Name");
    }
*/

    public String getCategoryText() {
        return this.companyName;
    }
    
    public String getCompanyName() {
        return companyName;
    }   
    
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    } 
    
}
