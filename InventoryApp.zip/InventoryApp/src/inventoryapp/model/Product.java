/*
 * Class: Product
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */
package inventoryapp.model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * @author Jennifer Rushton
 * 
 * Model class for a Product
 */
public class Product {
    
    private final ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private final IntegerProperty productID;
    private final StringProperty name;
    private final DoubleProperty price;
    private final IntegerProperty inStock;
    private int min;
    private int max;
    
    
    /**
     * The constructor - creates a product.
     * 
     * @param {Part} firstPart
     * @param {int} productID
     * @param {String} name
     * @param {double} price
     * @param {int} inStock
     * @param {int} min
     * @param {int} max
     */
    public Product(Part firstPart, int productID, String name, double price, int inStock, int min, int max) {
        this.productID = new SimpleIntegerProperty(productID);
        this.name = new SimpleStringProperty(name);
        this.price = new SimpleDoubleProperty(price);
        this.inStock = new SimpleIntegerProperty(inStock);
        setMin(min);
        setMax(max);
        addAssociatedPart(firstPart);
    }
    
    /**
     * The constructor - creates a product - without firstPart.
     * 
     * @param {int} productID
     * @param {String} name
     * @param {double} price
     * @param {int} inStock
     * @param {int} min
     * @param {int} max
     */
    public Product(int productID, String name, double price, int inStock, int min, int max) {
        this.productID = new SimpleIntegerProperty(productID);
        this.name = new SimpleStringProperty(name);
        this.price = new SimpleDoubleProperty(price);
        this.inStock = new SimpleIntegerProperty(inStock);
        setMin(min);
        setMax(max);
    }

    public int getInStock() {
        return inStock.get();
    }
    
    public void setInStock(int inStock) {
        this.inStock.set(inStock);
    }
    
    public IntegerProperty productInStockProperty() {
        return inStock;
    }
    
    public int getMax() {
        return max;
    }
    
    public void setMax(int max) {
        this.max = max;
    }
    
    public int getMin() {
        return min;
    }
    
    public void setMin(int min) {
        this.min = min;
    }
    
    public String getName() {
        return name.get();
    }
    
    public void setName(String name) {
        this.name.set(name);
    }
    
    public StringProperty productNameProperty() {
        return name;
    }

    public double getPrice() {
        return price.get();
    }
    
    public void setPrice(double price) {
        this.price.set(price);
    }
    
    public DoubleProperty productPriceProperty() {
        return price;
    }
    
    public int getProductID() {
        return productID.get();
    }
    
    public void setProductID(int productID) {
        this.productID.set(productID);
    }
    
    public IntegerProperty productIDProperty() {
        return productID;
    }
    
    /** Computes total price for all associated product parts
     * 
     * @return {int} total - total price of all parts associated with current product
     */
    public int getTotalPartsPrice() {
        int total = 0;
        
        for (Part part : this.associatedParts) {
            total += part.getPrice();
        }
        return total;
    }

    /** 
     * Adds associated part to Product
     * 
     * @param {Part} part - selected part is passed to add to Product
     */
    public void addAssociatedPart(Part part) {
        associatedParts.add(part);
    }
    
    /** 
     * Returns all associated parts for Product
     * 
     * @return {ObservableList<Part>} associatedParts - Returns parts associated
     * with Product
     */
    public ObservableList<Part> getAssociatedParts() {
        return associatedParts;
    }
    
    public boolean isProductIDValid(int productID) {
        
        return true;
    }
    
    /** 
     * Returns specified associated part from associatedParts list
     * 
     * @return {Part} Returns associated part based on partID if found, or null 
     * if not found
     */
    public Part lookupAssociatedPart(int partID) {
        for (int i = 0; i < associatedParts.size(); i++) {
            if (associatedParts.get(i).equals(partID)) {
                return associatedParts.get(i);
            }
        }
        return null;
    }

    /** 
     * Deletes specified associated part from associatedParts list
     * 
     * @return {boolean} Returns true if part is successfully found and removed 
     * from associatedParts list, and false if it is not found or removed
     */
    public boolean removeAssociatedPart(Part part) {
        if (isPartFound(part.getPartID()) == true) {
            associatedParts.remove(part);
            return true;
        } else {
            return false;
        }
    }

    /** 
     * Searches for specified associated part from associatedParts list
     * 
     * @return {boolean} Returns true if part is successfully found in 
     * associatedParts list, and false if it is not found
     */
    private boolean isPartFound(int partID) {
        for (int i = 0; i <= associatedParts.size(); i++) {
            if (associatedParts.get(i).equals(partID)) {
                return true;
            }
        }
        return false;
    }
    
}
