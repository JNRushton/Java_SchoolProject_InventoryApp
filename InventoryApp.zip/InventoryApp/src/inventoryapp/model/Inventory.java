/*
 * Class: Inventory
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */
package inventoryapp.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

/**
 * @author Jennifer Rushton
 * 
 * Model class for an Inventory
 */
public class Inventory {

    // Creates all parts and all products for program
    private static ObservableList<Product> products = FXCollections.observableArrayList();
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    
    // Creates part list and product list for search parameters
    private static ObservableList<Part> foundParts = FXCollections.observableArrayList();
    private static ObservableList<Product> foundProducts = FXCollections.observableArrayList();
    
   
    /** 
     * Returns foundParts observable array list to calling method.
     * 
     * @return {ObservableList<Part>} foundParts - returns observable array list
     */
    public static ObservableList<Part> getFoundParts() {
        return foundParts;
    }
    
    /** 
     * Returns foundProducts observable array list to calling method.
     * 
     * @return {ObservableList<Product>} foundProducts - returns observable array list
     */
    public static ObservableList<Product> getFoundProducts() {
        return foundProducts;
    }
    
    /** 
     * Returns allParts observable array list to calling method.
     * 
     * @return {ObservableList<Part>} allParts - returns observable array list
     */
    public static ObservableList<Part> getParts() {
        return allParts;
    }
    
    /** 
     * Returns products observable array list to calling method.
     * 
     * @return {ObservableList<Product>} products - returns observable array list
     */
    public static ObservableList<Product> getProducts() {
        return products;
    }
    
    /** 
     * Adds part to observable array list allParts.
     * 
     * @param {Part} part - adds to allParts
     */
    public void addPart(Part part) {
        allParts.add(part);
    }
    
    /** 
     * Adds product to observable array list products.
     * 
     * @param {Product} product - adds to products
     */
    public void addProduct(Product product) {
        products.add(product);
    }
    
    /**
     * Deletes part from observable array list allParts.
     * 
     * @param {Part} part
     * @return {boolean} returns true if part successfully found and removed,
     * and false if part was not found and removed
     */
    public boolean deletePart(Part part) {
        if (isPartFound(part.getPartID()) == true) {
            allParts.remove(part);
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Searches for corresponding part by partID in observable array 
     * list allParts.
     * 
     * @param {int} partID
     * @return {boolean} isFound - returns true if successfully found, false if not found
     */
    public static boolean isPartFound(int partID) {
        boolean isFound = false;
        
        for (Part p : allParts) {
            if (p.getPartID() == partID) {
                isFound = true;
            }
        }
        return isFound;
    }
    
    /**
     * Searches for corresponding product by productID in observable array 
     * list products.
     * 
     * @param {int} productID
     * @return {boolean} isFound - returns true if successfully found, false if not found
     */
    public static boolean isProductFound(int productID) {
        boolean isFound = false;
        
        for (Product p : products) {
            if (p.getProductID() == productID) {
                isFound = true;
            }
        }
        return isFound;
    }

    /**
     * Searches for corresponding part by partID in observable array 
     * list allParts.
     * 
     * @param {int} partID
     * @return {Part} returns part if successfully found, null if not found
     */
    public Part lookupPart(int partID) {
        for (int i = 0; i < allParts.size(); i++) {
            if (allParts.get(i).equals(partID)) {
                return allParts.get(i);
            }
        }
        return null;
    }
    
    /**
     * Searches for corresponding product by productID in observable array 
     * list products.
     * 
     * @param {int} productID
     * @return {Product} returns product if successfully found, null if not found
     */
    public Product lookupProduct(int productID) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).equals(productID)) {
                return products.get(i);
            }
        }
        return null;
    }

    /**
     * Deletes product from observable array list products.
     * 
     * @param {int} productID
     * @return {boolean} returns true if product successfully found and removed,
     * and false if product was not found and removed
     */
    public boolean removeProduct(int productID) {
        if (isProductFound(productID) == true) {
            products.remove(productID);
            return true;
        } else {
            return false; 
        }
    }
    
    /** 
     * Searches part table for a matching part ID or part name and returns all 
     * matching parts.
     * 
     * @param {String} searchText - search parameter
     * @return {ObservableList<Part>} - returns all matching parts
     */
    public static ObservableList<Part> searchForPart(String searchText) {
        
        // Clears found parts observable list to remove previously searched parts
        foundParts.clear();
        
        // Create boolean value to keep track if part has been found yet
        boolean isFound = false;
        
        // Loop through all parts and put all matching parts in temporary part list
        try {

            // First search for matching part IDs
            int i = Integer.parseInt(searchText);
            for (Part p : allParts) {
                if (p.getPartID() == i) {
                    isFound = true;
                    foundParts.add(p);
                }
            }
        }
        catch (NumberFormatException e) {

            // Now search for part names that contain search parameter
            for (Part p : allParts){
                if (p.getName().contains(searchText)) {
                    isFound = true;
                    foundParts.add(p);
                }
            }
        }

        // If no matching parts are found, raise message dialog
        if (isFound == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText("Error");
            alert.setContentText("Part not found");
            alert.showAndWait();
        }
        
        return getFoundParts();
    }
    
    /** 
     * Searches product table for a matching product ID or product name and 
     * returns all matching products.
     * 
     * @param {String} searchText - search parameter
     * @return {ObservableList<Product>} - returns all matching products
     */
    public static ObservableList<Product> searchForProduct(String searchText) {
        
        // Clears found products observable list to remove previously searched products
        foundProducts.clear();
        
        // Create boolean value to keep track if product has been found yet
        boolean isFound = false;
        
        // Loop through all products and put all matching products in temporary product list
        try {

            // First search for matching product IDs
            int i = Integer.parseInt(searchText);
            for (Product p : products){
                if (p.getProductID() == i) {
                    isFound = true;
                    foundProducts.add(p);
                }
            }
        }
        catch (NumberFormatException e) {

            // Now search for product names that contain search parameter
            for (Product p : products){
                if (p.getName().contains(searchText)) {
                    isFound = true;
                    foundProducts.add(p);
                }
            }
        }        

        // If no matching parts are found, raise message dialog
        if (isFound == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText("Error");
            alert.setContentText("Product not found");
            alert.showAndWait();
        }

        return getFoundProducts();
        
    }
    
    /** 
     * Searches for corresponding product by productID in observable array
     * list products, and if found, updates product.
     * 
     * NOTE: Not used. Modifying product directly using setters under 
     * ProductScreenController.handleSaveProduct()
     * 
     * @param {int} productID 
     */
/*    public void updateProduct(int productID) {
        if (isProductFound(productID) == true) {
            //update product
        } 
    }
*/

    /** 
     * Searches for corresponding part by partID in observable array
     * list allParts, and if found, updates part.
     * 
     * NOTE: Not used. Modifying part directly using setters under
     * PartController.handleSavePart()
     * 
     * @param {int} partID 
     */
/*    public void updatePart(int partID) {
        if (isPartFound(partID) == true) {
            //update part
        }
    }
*/
    
}
