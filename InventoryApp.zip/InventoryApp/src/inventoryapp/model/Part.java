/*
 * Class: Part
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */
package inventoryapp.model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * @author Jennifer Rushton
 * 
 * Model abstract class for a Part
 */
public abstract class Part {

    private final IntegerProperty partID;
    private final StringProperty name;
    private final DoubleProperty price;
    private final IntegerProperty inStock;
    private int min;
    private int max;
    private String category; // "Machine ID" or "Company Name"
    private String categoryText; // machineID for inhouse and companyName for outsourced
    
    /**
     * The constructor - creates a part.
     * 
     * @param {int} partID
     * @param {String} name
     * @param {double} price
     * @param {int} inStock
     * @param {int} min
     * @param {int} max
     * @param {String} category
     */
    public Part(int partID, String name, double price, int inStock, int min, int max, String category) {
        this.partID = new SimpleIntegerProperty(partID);
        this.name = new SimpleStringProperty(name);
        this.price = new SimpleDoubleProperty(price);
        this.inStock = new SimpleIntegerProperty(inStock);
        setMin(min);
        setMax(max);
        setCategory(category);
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getCategoryText() {
        return categoryText;
    }
  
    public void setCompanyName(String companyName) {
        // Set category text for Company Name
    }
    
    public void setMachineID(int machineID) {
        // Set category text for Machine ID
    }
    
    public int getInStock() {
        return inStock.get();
    }

    public void setInStock(int inStock) {
        this.inStock.set(inStock);
    }
    
    public IntegerProperty partInStockProperty() {
        return inStock;
    }
    
    public int getMax() {
        return max;
    }
    
    public void setMax(int max) {
        this.max = max;
    }
    
    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }
    
    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }
    
    public StringProperty partNameProperty() {
        return name;
    }
    
    public int getPartID() {
        return partID.get();
    }
    
    public void setPartID(int partID) {
        this.partID.set(partID);
    }
    
    public IntegerProperty partIDProperty() {
        return partID;
    }

    public double getPrice() {
        return price.get();
    }
    
    public void setPrice(double price) {
        this.price.set(price);
    }
    
    public DoubleProperty partPriceProperty() {
        return price;
    }
    
    /** Verifies that the min is less than max and max is greater than min
     * for the part
     * 
     * @return {boolean} isVerified - returns true if criteria met, otherwise false
     */
/*    public boolean verifyMinMax() {
        boolean isVerified = false;
        
        if (this.getMin() < this.getMax()) {
            isVerified = true;
        }
        return isVerified;
    }
*/
    /** Verifies that the inventory (inStock) value is between the min and max
     * values for the part
     * 
     * @return {boolean} isVerified - returns true if criteria met, otherwise false
     */
/*    public boolean verifyInStock() {
        boolean isVerified = false;
        
        if ((this.getMin() < this.getInStock()) && (this.getInStock() < this.getMax())) {
            isVerified = true;
        }
        return isVerified;
    }
*/

}
