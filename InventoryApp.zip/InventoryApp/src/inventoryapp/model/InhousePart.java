/*
 * Class: InhousePart
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */
package inventoryapp.model;

/**
 * @author Jennifer Rushton
 * 
 * Model class for an InhousePart
 */
public class InhousePart extends Part {
    
    private int machineID;
    
    
    /**
     * The constructor - creates an Inhouse part.
     * 
     * @param {int} partID
     * @param {String} name
     * @param {double} price
     * @param {int} inStock
     * @param {int} min
     * @param {int} max
     * @param {int} machineID
     */
    public InhousePart(int partID, String name, double price, int inStock, int min, int max, int machineID) {
                       super(partID, name, price, inStock, min, max, "Machine ID");
        setMachineID(machineID);
    }
    
    /**
     * The constructor - creates an Inhouse part - without machineID
     * 
     * @param {int} partID
     * @param {String} name
     * @param {double} price
     * @param {int} inStock
     * @param {int} min
     * @param {int} max
     */
/*    public InhousePart(int partID, String name, double price, int inStock, int min, int max) {
                       super(partID, name, price, inStock, min, max, "Machine ID");
    }
*/
    
    public String getCategoryText() {
        return Integer.toString(this.machineID);
    }
    
    public int getMachineID() {
        return machineID;
    }
        
    public void setMachineID(int machineID) {
        this.machineID = machineID;
    }
    
}
