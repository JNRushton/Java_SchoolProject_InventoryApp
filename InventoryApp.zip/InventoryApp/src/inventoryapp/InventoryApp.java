/*
 * Class: InventoryApp
 *
 * Version: Final
 *
 * Copyright (C) June 2018 Jennifer Rushton <jrusht1@wgu.edu>
 * 
 * This file is part of JenniferRushtonInventoryApp Inventory project 
 * for WGU's Software I course.
 */
package inventoryapp;

import inventoryapp.model.InhousePart;
import inventoryapp.model.Inventory;
import inventoryapp.model.OutsourcedPart;
import inventoryapp.model.Part;
import inventoryapp.model.Product;
import inventoryapp.view_controller.PartController;
import inventoryapp.view_controller.MainDisplayController;
import inventoryapp.view_controller.ProductScreenController;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * @author Jennifer Rushton 6/18/2018
 * 
 * This application lets a user add, modify, or delete Parts or Products for 
 * inventory purposes. Each Product contains one or more Parts. 
 */
public class InventoryApp extends Application {
    
    private Stage primaryStage;
    private BorderPane rootLayout;
    
    /**
     * The constructor - creates sample data
     */
    public InventoryApp() {
        
        // Sample parts
        Inventory.getParts().add(new InhousePart(1, "Roller", 1.99, 50, 10, 100, 3241));
        Inventory.getParts().add(new InhousePart(2, "Ink", 31.78, 30, 8, 35, 9876));
        Inventory.getParts().add(new OutsourcedPart(3, "Toner Cartridge", 49.98, 13, 4, 20, "Staples"));
        Inventory.getParts().add(new OutsourcedPart(4, "Fuser", 134.81, 2, 1, 4, "Office Depot"));
        Inventory.getParts().add(new InhousePart(5, "Drum", 74.33, 3, 1, 10, 3513));
        Inventory.getParts().add(new OutsourcedPart(6, "Circuit Board", 168.45, 2, 1, 3, "SparkFun"));
        Inventory.getParts().add(new InhousePart(7, "Paper Tray", 14.67, 5, 2, 10, 5748));
        Inventory.getParts().add(new InhousePart(8, "Staple Cartridge", 2.43, 65, 10, 100, 8437));
        Inventory.getParts().add(new OutsourcedPart(9, "Modem", 32.77, 2, 1, 3, "Office Depot"));
                
        // Sample products
        // electric red stapler - staple cartridge
        Inventory.getProducts().add(new Product(Inventory.getParts().get(7), 1, "Electric Red Stapler", 10.82, 13, 1, 15));
        
        // printer - rollers, ink, paper tray, circuit board
        Inventory.getProducts().add(new Product(Inventory.getParts().get(0), 2, "Printer", 254.99, 6, 2, 10));
        Inventory.getProducts().get(1).addAssociatedPart(Inventory.getParts().get(0));
        Inventory.getProducts().get(1).addAssociatedPart(Inventory.getParts().get(1));
        Inventory.getProducts().get(1).addAssociatedPart(Inventory.getParts().get(5));
        Inventory.getProducts().get(1).addAssociatedPart(Inventory.getParts().get(6));
        
        // fax - rollers, fuser, toner cartrdige, drum, circuit board, modem, staple cartridge
        Inventory.getProducts().add(new Product(Inventory.getParts().get(0), 3, "Fax Machine", 539.48, 2, 1, 5));
        Inventory.getProducts().get(2).addAssociatedPart(Inventory.getParts().get(0));
        Inventory.getProducts().get(2).addAssociatedPart(Inventory.getParts().get(3));
        Inventory.getProducts().get(2).addAssociatedPart(Inventory.getParts().get(2));
        Inventory.getProducts().get(2).addAssociatedPart(Inventory.getParts().get(4));
        Inventory.getProducts().get(2).addAssociatedPart(Inventory.getParts().get(5));
        Inventory.getProducts().get(2).addAssociatedPart(Inventory.getParts().get(8));
        Inventory.getProducts().get(2).addAssociatedPart(Inventory.getParts().get(7));
        
        // copier - rollers, fuser, toner cartridge, drum, paper tray, circuit board, staple cartridge
        Inventory.getProducts().add(new Product(Inventory.getParts().get(0), 4, "Copier", 603.29, 5, 2, 15));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(0));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(0));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(0));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(3));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(2));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(4));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(6));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(5));
        Inventory.getProducts().get(3).addAssociatedPart(Inventory.getParts().get(7));
        
    }    
    
    /**
     * Separate start method from constructor to enable throwing an exception,
     * if needed. Initializes both root and main display interfaces.
     * 
     * @param {Stage} stage
     * 
     * @exception java.lang.Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        try {
            
            // Set primary stage and title
            this.primaryStage = stage;
            this.primaryStage.setTitle("Inventory Management System");
            
            // Initialize root display
            initRootDisplay();
            
            // Initialize main display
            showMainDisplay();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    /**
     * Returns the main stage
     * 
     * @return {Stage} returns main stage
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }
    
    /**
     * Initializes the root display container
     * 
     * @exception java.lang.Exception
     */
    public void initRootDisplay() throws Exception {
        try {
            
            // Loads root dislay from FXML file
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(InventoryApp.class.getResource("view_controller/RootDisplay.fxml"));
            rootLayout = (BorderPane) loader.load();
            
            // Shows the scene containing the root display
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Shows the add parts display popup dialog
     * 
     * @return {boolean} Returns true if the user clicked OK, otherwise 
     * returns false
     * 
     * @exception java.lang.Exception
     */
    public boolean showAddPartsDisplay() throws Exception {
        try {
            
            // Load FXML file
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(InventoryApp.class.getResource("view_controller/Part.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            
            // Give the controller access to the inventory app
            PartController controller = loader.getController();
            controller.setDisplay(this);
            
            // Create the new stage for the popup dialog
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Add Part");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            controller.setDialogStage(dialogStage);
            
            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();
            return controller.isOkClicked();      
            
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Shows the add products display popup dialog
     * 
     * @return {boolean} Returns true if the user clicked OK, otherwise 
     * returns false
     * 
     * @exception java.lang.Exception
     */
    public boolean showAddProductsDisplay() throws Exception {
        try {
            
            // Load FXML file
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(InventoryApp.class.getResource("view_controller/ProductScreen.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            
            // Give the controller access to the inventory app
            ProductScreenController controller = loader.getController();
            controller.setDisplay(this);
            
            // Create the new stage for the popup dialog
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Add Product");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            controller.setDialogStage(dialogStage);
            
            // Show the dialog and wait until the user closes it
            controller.setTitle("Add Product");
            dialogStage.showAndWait();
            return controller.isOkClicked();      
            
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Shows the main display overview inside the root display
     * 
     * @exception java.lang.Exception
     */
    public void showMainDisplay() throws Exception {
        try {
            
            // Loads main display from FXML file
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(InventoryApp.class.getResource("view_controller/MainDisplay.fxml"));
            AnchorPane mainDisplay = (AnchorPane) loader.load();
            
            // Sets main display into the center of root display
            rootLayout.setCenter(mainDisplay);
            
            // Gives the controller access to the main display
            MainDisplayController controller = loader.getController();
            controller.setDisplay(this);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Shows the modify parts display popup dialog
     * 
     * @return {boolean} Returns true if the user clicked OK, otherwise 
     * returns false
     * 
     * @exception java.lang.Exception
     */
    public boolean showModifyPartsDisplay(Part part) {
        try {
            
            // Load FMXL file
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(InventoryApp.class.getResource("view_controller/Part.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            
            // Give the controller access to the inventory app
            PartController controller = loader.getController();
            controller.setDisplay(this);
            
            // Create the new stage for the popup dialog
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Modify Part");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            controller.setDialogStage(dialogStage);
            controller.setTitle("Modify Part");
            
            //sends selected product to the popup dialog
            controller.setPart(part);
            
            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();
            return controller.isOkClicked();      
            
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Shows the modify products display popup dialog
     * 
     * @return {boolean} Returns true if the user clicked OK, otherwise 
     * returns false
     * 
     * @exception java.lang.Exception
     */
    public boolean showModifyProductsDisplay(Product product) {
        try {
            
            // Load FXML file
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(InventoryApp.class.getResource("view_controller/ProductScreen.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            
            // Give the controller access to the inventory app
            ProductScreenController controller = loader.getController();
            controller.setDisplay(this);
            
            // Create the new stage for the popup dialog
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Modify Product");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            controller.setDialogStage(dialogStage);
            controller.setTitle("Modify Product");
            
            //sends selected product to the popup dialog
            controller.setProduct(product);
            
            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();           
            return controller.isOkClicked();      
            
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
}